import requests

from util.config_util import get_config


def check_ip(ip):
    apikey = get_config("Domain", "key")
    url = f"https://api.ipregistry.co/{ip}?key={apikey}"
    response = requests.get(url).json()
    for i in response:
        print(f"{i}:{response[i]}")
    country_set = ["AU"]
    country_lock = True
    country_code = response["location"]["country"]["code"]
    if country_code not in country_set and country_lock is True:
        return False

    contype = response["connection"]["type"]
    accepte_contype = ["cdn", "hosting", "education"]
    if contype in accepte_contype:
        return False

    isthreat = response["security"]["is_threat"]
    if isthreat is True:
        return False

    is_cloud = response["security"]["is_cloud_provider"]
    if is_cloud is True:
        return False
    return True
