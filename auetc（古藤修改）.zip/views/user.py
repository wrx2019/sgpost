import configparser

import jwt
from flask import Blueprint, jsonify, request

from models import Role
from util.authorize import create_token, login_required, admin_required
from util.redis_util import save_jwt, get_jwt

user = Blueprint("user", __name__, url_prefix="/user")


def get_config(section, key):
    config = configparser.ConfigParser()
    path = "message.conf"
    config.read(path)
    return config.get(section, key)


@user.route("/login", methods=["POST", "OPTIONS", "GET"])
def user_login():
    if request.method == "POST":
        username = request.get_json()["username"]
        password = request.get_json()["password"]
        users = Role.get_all_user()
        for u in users:
            if u["username"] == username and u["password"] == password:
                token = create_token(username, password)
                save_jwt(username, token)
                return jsonify({"code": 20000, "data": {"token": token}})
        else:
            return jsonify({"code": 60204, "message": "密码或用户名错误"})
    return jsonify({"code": 50000, "data": {"msg": "非法访问"}})


@user.route("/info")
@login_required
def user_info():
    auth = request.args.get("token")
    salt = "iv%i6xo7l8_t9bf_u!8#g#m*)*+ej@bek6)(@u3kh*42+unjv="
    username = jwt.decode(auth, salt, algorithms=["HS256"]).get("username")
    user_roles = Role.get_user(username)
    return jsonify(
        {
            "code": 20000,
            "data": {
                "roles": [user_roles["role"]],
                "introduction": "Fuck All Free",
                "avatar": "https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif",
                "name": user_roles["username"],
            },
        }
    )


@user.route("/logout", methods=["POST", "OPTIONS", "GET"])
def user_logout():
    return jsonify({"code": 20000, "data": {"token": "admin-token"}})


@user.route("/fetch_all", methods=["GET"])
@admin_required
def user_get():
    all_user = Role.get_all_user()
    return jsonify({"code": 20000, "data": {"users": all_user}})


@user.route("/add", methods=["POST"])
@admin_required
def add_user():
    if request.method == "POST":
        username = request.get_json()["username"]
        password = request.get_json()["password"]
        role = request.get_json()["role"]
        if role == "普通用户":
            role = "editor"
        elif role == "管理员":
            role = "admin"
        if username and password and role:
            results = Role.add_user(username, password, role)
            if results:
                return jsonify({"code": 20000, "msg": "add success"})
            else:
                return jsonify({"code": 20000, "msg": "add failed"})
        else:
            return jsonify({"code": 20000, "msg": "add failed"})


@user.route("/delete", methods=["POST"])
@admin_required
def delete_user():
    if request.method == "POST":
        username = request.get_json()["username"]
        if username:
            results = Role.delete_user(username)
            if results:
                save_jwt(username, "None")
                return jsonify({"code": 20000, "msg": "success"})
            else:
                return jsonify({"code": 20000, "msg": "failed"})
        else:
            return jsonify({"code": 20000, "msg": "failed"})


@user.route("/change_password", methods=["POST"])
@admin_required
def change_password():
    if request.method == "POST":
        username = request.get_json()["username"]
        password = request.get_json()["password"]
        if username:
            results = Role.update_password(username, password)
            if results:
                save_jwt(username, "None")
                return jsonify({"code": 20000, "msg": "success"})
            else:
                return jsonify({"code": 20000, "msg": "failed"})
        else:
            return jsonify({"code": 20000, "msg": "failed"})


@user.route("/fetch_users", methods=["GET"])
@admin_required
def fetch_users():
    all_user = Role.get_all_user()
    return jsonify(
        {
            "code": 20000,
            "data": {
                "items": [x["username"] for x in all_user if x["role"] != "admin"]
            },
        }
    )
