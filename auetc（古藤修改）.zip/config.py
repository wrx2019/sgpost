# 配置 sqlalchemy  "数据库+数据库驱动://数据库用户名:密码@主机地址:端口/数据库?编码"
from util.config_util import get_config

user = get_config("DB", "USER")
pwd = get_config("DB", "PASS")
dbname = get_config("DB", "DBNAME")
SQLALCHEMY_DATABASE_URI = (
    f"mysql+mysqlconnector://{user}:{pwd}@127.0.0.1:3306/{dbname}?charset=utf8"
)
pool_pre_ping = True
SQLALCHEMY_TRACK_MODIFICATIONS = True
CELERY_BROKER_URL = "redis://localhost:6379/0"
CELERY_RESULT_BACKEND = "redis://localhost:6379/0"
