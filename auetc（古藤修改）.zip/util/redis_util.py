import json

from flask_redis import FlaskRedis

from util.config_util import get_config

REDIS_URL = get_config("REDIS", "URL")
redis_client = FlaskRedis()


def set_online(appid):
    redis_client.set(appid, "online", ex=int(get_settings()["online_out_time"]))


def check_online(appid):
    return redis_client.get(appid)


def set_settings(seting_data):
    redis_client.hset("global_setting", "default", json.dumps(seting_data))


def get_settings():
    set_reslut = json.loads(redis_client.hget("global_setting", "default"))
    return set_reslut


def save_jwt(username, jwt):
    redis_client.hset("users_jwt", username, jwt)


def get_jwt(username):
    token = redis_client.hget("users_jwt", username)
    return token.decode()


def save_ip(ip, status):
    ip = ip.encode()
    if ip in redis_client.lrange("white_ip_list", 0, -1) or ip in redis_client.lrange(
        "black_ip_list", 0, -1
    ):
        return
    if status is True:
        redis_client.lpush("white_ip_list", ip)
    elif status is False:
        redis_client.lpush("black_ip_list", ip)
    return True


def get_ip(ip):
    ip = ip.encode()
    print(redis_client.lrange("white_ip_list", 0, -1))
    print(redis_client.lrange("black_ip_list", 0, -1))
    if ip in redis_client.lrange("white_ip_list", 0, -1):
        return True
    elif ip in redis_client.lrange("black_ip_list", 0, -1):
        return False
    else:
        return None
