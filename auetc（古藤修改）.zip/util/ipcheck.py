from guardian_domain import check_ip
from util.redis_util import get_ip, save_ip


def ip_find(ip):
    ip_status = get_ip(ip)
    if ip_status is not None:
        return ip_status
    else:
        ip_pass = False
        try:
            ip_pass = check_ip(str(ip))
            save_ip(ip, ip_pass)
        except Exception as msg:
            try:
                ip_pass = check_ip(str(ip))
                save_ip(ip, ip_pass)
            except Exception as msg:
                ip_pass = False
                print(msg)
        finally:
            return ip_pass
